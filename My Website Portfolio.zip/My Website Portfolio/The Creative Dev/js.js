//[08:27] Stephan Williams
/*Interview Question

Problem Statement : We receive a sentence as input parameter and 
need you write a method that returns the every alternating word in that sentence in the reversed order they came in
Example Input( I love coding very much)
Example Response ( much coding I )*/

function reverse_order(string sentence) {
    a = [1,2,3,4,5]
    for (int b=0, )


}



